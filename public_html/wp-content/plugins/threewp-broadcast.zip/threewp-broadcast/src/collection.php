<?php

namespace threewp_broadcast;

/**
	@brief		Base collection class for Broadcast.
	@details	I tired of referring to the SDk each time I wanted a new collection.
	@since		2015-05-31 11:55:27
**/
class collection
	extends \plainview\sdk_broadcast\collections\collection
{
}
