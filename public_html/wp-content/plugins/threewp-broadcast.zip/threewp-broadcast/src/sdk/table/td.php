<?php

namespace plainview\sdk_broadcast\table;

/**
	@brief		Cell of type TD.
	@since		20130430
**/
class td
	extends cell
{
	public $tag = 'td';
}
