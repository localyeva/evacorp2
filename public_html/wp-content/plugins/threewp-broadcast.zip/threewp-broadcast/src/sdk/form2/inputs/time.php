<?php

namespace plainview\sdk_broadcast\form2\inputs;

/**
	@brief		Input for time.
	@author		Edward Plainview <edward@plainview.se>
	@copyright	GPL v3
	@version	20130524
**/
class time
	extends number
{
	public $type = 'time';
}

