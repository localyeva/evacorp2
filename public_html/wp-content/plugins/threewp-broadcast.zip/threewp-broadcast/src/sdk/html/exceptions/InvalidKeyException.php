<?php

namespace plainview\sdk_broadcast\html\exceptions;

class InvalidKeyException extends \Exception
{
}
