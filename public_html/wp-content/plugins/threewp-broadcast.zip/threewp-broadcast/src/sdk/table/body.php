<?php

namespace plainview\sdk_broadcast\table;

/**
	@brief		Body section of table.
	@since		20130430
	@version	20130430
**/
class body
	extends section
{
	public $tag = 'tbody';
}
